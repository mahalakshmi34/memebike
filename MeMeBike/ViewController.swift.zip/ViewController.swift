//
//  ViewController.swift
//  MeMeBike
//
//  Created by IGNASI REBISTAN on 4/28/21.
//  Copyright © 2021 MeMeWorldWide. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var requestOtpBtn: UIButton!
    
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var signupBtn: UIButton!
    
    @IBOutlet weak var mobilenumberTxt: UITextField!
    
    @IBOutlet weak var countryText: UITextField!
    @IBOutlet weak var loginImageView: UIImageView!
    
    @IBOutlet weak var notmemberLabel: UILabel!
    @IBOutlet weak var loginScrollView: UIScrollView!
    
    @IBOutlet weak var subView: UIView!
    
    
    var isExpand : Bool = false
    var alertMessage = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        roundedCorners()
        dropShadow()
        // Do any additional setup after loading the view.
        
        //self.view.addSubview(loginScrollView)
        mobilenumberTxt.delegate = self
        signupUnderline()
        
        self.view.endEditing(true)
        //signupBtn : CGFloat = notmemberLabel.frame.size.width + 5
        
        view.addSubview(loginScrollView)
        
        loginScrollView.addSubview(subView)

        subView.addSubview(loginImageView)
        subView.addSubview(loginView)
        
        tapGesture()
        handleTap()
        //tapTextfield()
    
       //addObserver()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        addObserver()
    }
    
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        removeObserver()
    }
    
    
    func tapGesture() {
       
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        loginScrollView.addGestureRecognizer(tap)
    }
    
    @objc func handleTap(_ sender: UITapGestureRecognizer? = nil) {

        self.view.endEditing(true)
        
        keyboardDisappear()
        
        
    }
    
    func buttonFrame() {
        
        notmemberLabel.frame.size.width = 242
        
        var button = signupBtn
        button?.frame.origin.x = notmemberLabel.frame.size.width + 34
        //  signupBtn.layer.borderWidth = 2.0
        //signupBtn.setAttributedTitle(NSAttributedString, for: .normal)
        
        countryText.frame.size.height = 45
        mobilenumberTxt.frame.size.height = 45
        
    }
    
    func dropShadow () {
        
        
        mobilenumberTxt.addShadowToTextField(cornerRadius: 3)
        mobilenumberTxt.addShadowToTextField(color: UIColor.gray, cornerRadius: 3)
                
        countryText.addShadowToTextField(cornerRadius: 3)
        countryText.addShadowToTextField(color: UIColor.gray, cornerRadius: 3)
        
    }
    
    
    func keyboardDisappear() {
        
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillHideNotification, object: nil, queue: nil) {
            
            notification in
            
            self.keyboardWillHide(notification: notification)
        }
    }
    
    func addObserver () {
        
        
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification, object: nil, queue: nil) {
            
            notification in
            
            self.keyboardWillShow(notification: notification)
        }
    }
    
    func keyboardWillShow(notification: Notification) {
        
        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
            let keyboardInfo = userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue
            let keyboardSize = keyboardInfo.cgRectValue.size
     //   let contentInsets = UIEdgeInsets(top: 0, left: 0,bottom: keyboardSize.height, right: 0)
        
        //let screenSize: CGRect = UIScreen.main.bounds
        
      //  let subviewHeight =  screenSize.height
        
     //   subView.frame.origin.y -= keyboardSize.height
        
        
      //  print("subView height",subView.frame.origin.y )
        
       // self.loginScrollView.contentSize = CGSize(width: self.view.frame.size.width, height: screenSize.height  + keyboardSize.height )
        
        let contentInset = UIEdgeInsets(top: 0, left:0, bottom:mobilenumberTxt.frame.origin.y - keyboardSize.height , right: 0)
        
        loginScrollView.contentInset = contentInset
        
        loginScrollView.scrollIndicatorInsets = contentInset
        
      //  self.loginScrollView.contentSize = CGSize(width: screenSize.width, height: screenSize.height + keyboardSize.height)
        
       // print("scrollview",loginScrollView.frame.size.height , keyboardSize.height)
        
     //   let contentInset = UIEdgeInsets(top: 0, left: 0, bottom: frame.height, right: 0)
        //loginScrollView.contentInset = contentInset
    }
    
    func keyboardWillHide(notification: Notification) {
        
        
//        let userInfo: NSDictionary = notification.userInfo! as NSDictionary
//            let keyboardInfo = userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue
//            let keyboardSize = keyboardInfo.cgRectValue.size

        
  //      self.loginScrollView.contentSize = .zero
        
        //print(loginScrollView.contentSize)
        
     //   self.subView.frame.origin.y = 0
        
       // print("print",self.view.frame.origin.y)
        
        loginScrollView.contentInset = .zero
        
        loginScrollView.scrollIndicatorInsets = .zero
        
        
//        loginScrollView.contentInset = UIEdgeInsets.zero
//        loginScrollView.scrollIndicatorInsets  = UIEdgeInsets.zero
    }
    
    func removeObserver() {
        NotificationCenter.default.removeObserver(self)
    }
    
    
    func signupUnderline() {
        var attributedString = NSMutableAttributedString(string:"Sign Up")
        var attrs = [
            NSAttributedString.Key.font : UIFont.systemFont(ofSize: 19.0),
            NSAttributedString.Key.foregroundColor : UIColor.blue
        ]
        var gString = NSMutableAttributedString(string:"g", attributes:attrs)
        attributedString.append(gString)
        
        signupBtn.titleLabel?.attributedText = attributedString;
    }
    

//
//    @objc func handle (keyboardAppear notification: Notification) {
//
//        print("Call")
//        if !isExpand {
//
//            print("Call == EXECUTE")
//
//            if let userInfo = notification.userInfo,
//                let keyboardRectangle = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
//                print(keyboardRectangle.height)
//
//                self.loginScrollView.contentSize = CGSize(width: self.view.frame.size.width, height: self.loginScrollView.frame.size.height + keyboardRectangle.height)
//
//                isExpand = true
//            }
//        }
//    }

//    @objc func handle (keyboardDisAppear notification: Notification) {
//        if isExpand {
//
//            if let userInfo = notification.userInfo,
//                let keyboardRectangle = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
//                print(keyboardRectangle.height)
//           // self.view.frame.origin.y += 150
//            self.loginScrollView.contentSize = CGSize(width: self.view.frame.size.width, height: self.loginScrollView.frame.size.height - 350)
//            isExpand = false
//            self.view.endEditing(true)
//        }
//    }
//
//}
    func roundedCorners() {
        requestOtpBtn.layer.cornerRadius = 20
        mobilenumberTxt.layer.cornerRadius = mobilenumberTxt.frame.size.height / 2
        
    }
    
    
    func validation()  {
        
        //        var invalidphone = ""
        //         let regEx = "^\\+(?:[0-9]?){6,14}[0-9]$"
        //        let phoneCheck = NSPredicate(format: "SELF MATCHES[c] %@", regEx)
        //        phoneCheck.evaluate(with: phone)
        
        if mobilenumberTxt.text?.count == 0 {
            let alert = UIAlertController (title: "Alert", message: "Enter mobile number", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        }
        
        else if (mobilenumberTxt.text!.count > 10) {
            
            let alert = UIAlertController (title: "Alert", message: "invalid phone number", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            self.present(alert, animated: true, completion:     nil)
            
        }
        
        else if (mobilenumberTxt.text!.count < 10) {
            
            let alert = UIAlertController (title: "Alert", message: "invalid phone number", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
            
        }
    }
 
    //  func getPhoneNumberValidation (phone:String) -> String {
    //
    //    var invalidPhone = ""
    //    if (phone.count == 0) {
    //        return "Please enter phone number"
    //    }
    //        let regEx = "^\\+(?:[0-9]?){6,14}[0-9]$"
    //
    //        let phoneCheck = NSPredicate(format: "SELF MATCHES[c] %@", regEx)
    //    if (!phoneCheck.evaluate(with: phone)) {
    //         invalidPhone = "invalid phone number"
    //
    //        let alert = UIAlertController (title: "Alert", message: alertMessage, preferredStyle: .alert)
    //                 alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
    //
    //                 self.present(alert, animated: true, completion:     nil)
    //
    //        self.view.endEditing(true)
    //    }
    //        return invalidPhone
    //    }
    //
    //    func alertmessage() {
    //
    //        let phonevalidationMessage = getPhoneNumberValidation(phone: mobilenumberTxt.text!)
    //
    //        if (phonevalidationMessage.count > 0) {
    //            alertMessage = phonevalidationMessage
    //        }
    //
    //        }
    //
    //
    
    @IBAction func requestAction(_ sender: UIButton) {
        
        //alertmessage()
        validation()
        
        keyboardDisappear()
        
       self.view.endEditing(true)
        
        performSegue(withIdentifier: "home", sender: self)
        
       
    }
    
    @IBAction func signBtn(_ sender: UIButton) {
        
       // validation()
        
        //self.view.endEditing(true)
        //let vc = SignUpViewController()
        
        
        //navigationController?.pushViewController(vc, animated: true)
     
        //performSegue(withIdentifier: "signup", sender: self)
        
        
    }
    
    
}

    
    
extension String {
    var isValidPhone: Bool {
        let regularExpressionForPhone = "^\\d{3}-\\d{3}-\\d{4}$"
        let testPhone = NSPredicate(format:"SELF MATCHES %@", regularExpressionForPhone)
        return testPhone.evaluate(with: self)
    }
}


